# simple_rasa_chat.py

import requests
import asyncio
from typing import List, Dict, Any

class RasaChatClient:
    def __init__(self, base_url: str = "http://localhost:5005"):
        self.webhook_url = f"{base_url}/webhooks/rest/webhook"
    
    async def send_message(self, message: str) -> List[str]:
        try:
            response = requests.post(
                self.webhook_url,
                json={"sender": "user", "message": message},
                timeout=10
            )
            
            if response.status_code == 200:
                bot_responses = []
                for bot_response in response.json():
                    if "text" in bot_response:
                        bot_responses.append(f"Bot: {bot_response['text']}")
                return bot_responses
            else:
                return [f"Error: Received status code {response.status_code}"]
                
        except requests.exceptions.RequestException as e:
            return [f"Error: Could not connect to Rasa server: {str(e)}"]

    async def start_conversation(self):
        print("Bot: Hello! I'm your Rasa chatbot. Type 'quit' to exit.")
        
        while True:
            try:
                # Get user input
                user_message = input("You: ").strip()
                
                # Check for exit command
                if user_message.lower() == 'quit':
                    print("Bot: Goodbye!")
                    break
                
                # Get bot response
                bot_responses = await self.send_message(user_message)
                
                # Print bot responses
                for response in bot_responses:
                    print(response)
                    
            except KeyboardInterrupt:
                print("\nBot: Conversation ended by user. Goodbye!")
                break
            except Exception as e:
                print(f"Error: {str(e)}")
                break

async def main():
    client = RasaChatClient()
    await client.start_conversation()

if __name__ == "__main__":
    asyncio.run(main())
